package nordmods.biscuit_roll.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import libs.gg.moonflower.molangcompiler.api.MolangEnvironment;
import libs.gg.moonflower.molangcompiler.api.MolangEnvironmentBuilder;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.*;
import nordmods.biscuit_roll.client.renderer.layer.BRRenderLayer;
import nordmods.biscuit_roll.client.state.ClientStateDataTypes;
import nordmods.biscuit_roll.common.animation.BRAnimatedObject;
import nordmods.biscuit_roll.common.animation.QueryHelper;
import nordmods.biscuit_roll.common.model.BRModel;
import nordmods.biscuit_roll.common.model.BRModelProvider;
import nordmods.biscuit_roll.common.state.StateDataTypes;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.NonNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/// Implementation of {@link BRRenderer} for {@link Entity}
/// @see BRObjectRenderer
public abstract class BREntityRenderer<E extends Entity & BRAnimatedObject, S extends EntityRenderState> extends EntityRenderer<E, S> implements BRRenderer<S> {
    private final BRModelProvider modelProvider;
    private final LivingRenderStateGetter<LivingEntity, LivingEntityRenderState, EntityModel<LivingEntityRenderState>> livingEntityStateGetter; // Some unintended way to use renderer to easily apply everything necessary from vanilla entity renderers
    private final MobRenderStateGetter<Mob, LivingEntityRenderState, EntityModel<LivingEntityRenderState>> mobRenderStateGetter;
    private final List<BRRenderLayer> renderLayers = new ArrayList<>();

    protected BREntityRenderer(EntityRendererProvider.Context context, BRModelProvider modelProvider) {
        super(context);
        this.modelProvider = modelProvider;
        this.livingEntityStateGetter = new LivingRenderStateGetter<>(context, getFlipDegrees());
        this.mobRenderStateGetter = new MobRenderStateGetter<>(context);
    }

    @Override
    public Collection<BRRenderLayer> getRenderLayers() {
        return renderLayers;
    }

    @Override
    public void beforeSubmit(S state, PoseStack poseStack, SubmitNodeCollector submitNodeCollector, CameraRenderState cameraRenderState) {
        float scale = state.getStateData(StateDataTypes.SCALE, 1f);
        poseStack.scale(scale, scale, scale);
        if (state instanceof LivingEntityRenderState livingState) {
            setupRotations(livingState, poseStack, state.getStateData(StateDataTypes.BODY_YAW, 0f), scale);
        }
        poseStack.scale(-1, -1, 1);
    }

    @Override
    public void submit(S state, @NonNull PoseStack poseStack, @NonNull SubmitNodeCollector submitNodeCollector, @NonNull CameraRenderState cameraRenderState) {
        submitBRModel(state, poseStack, submitNodeCollector, cameraRenderState);
        super.submit(state, poseStack, submitNodeCollector, cameraRenderState);
    }

    @Override
    public BRModelProvider getModelProvider() {
        return modelProvider;
    }

    /// Updates variables and queries for each controller during {@link BREntityRenderer#extractRenderState(Entity, EntityRenderState, float)}.
    /// Note: `query.anim_time` gets updated during {@link BRModel#applyAnimations(MolangEnvironment, Collection)} regardless
    /// @param builder provided by controller Molang environment
    /// @param entity entity from which data for queries and values is gotten
    /// @param tickDelta current tick progress
    /// @see QueryHelper
    public void updateControllerVariables(MolangEnvironmentBuilder<?> builder, E entity, float tickDelta) {}

    @Override
    public void extractRenderState(E entity, S state, float tickDelta) {
        entity.getAnimationControllers().forEach(controller -> updateControllerVariables(controller.getEnvironment().edit(), entity, tickDelta));
        super.extractRenderState(entity, state, tickDelta);
        state.setStateData(ClientStateDataTypes.INVISIBLE, state.isInvisible);
        if (state instanceof LivingEntityRenderState livingState && entity instanceof LivingEntity livingEntity) {
            if (entity instanceof Mob mob) mobRenderStateGetter.fillRenderState(mob, livingState, tickDelta);
            else livingEntityStateGetter.fillRenderState(livingEntity, livingState, tickDelta);
            state.setStateData(ClientStateDataTypes.OVERLAY_TEXTURE, LivingEntityRenderer.getOverlayCoords(livingState, livingEntityStateGetter.getWhiteOverlayProgress(livingState)));
            state.setStateData(StateDataTypes.BODY_YAW, livingState.bodyRot);
            state.setStateData(StateDataTypes.SCALE, livingState.scale * livingState.ageScale);
            state.setStateData(ClientStateDataTypes.INVISIBLE, livingState.isInvisibleToPlayer);
        }
        state.setStateData(ClientStateDataTypes.OUTLINE_COLOR, state.outlineColor);
        state.setStateData(ClientStateDataTypes.LIGHT, state.lightCoords);

        state.setStateData(StateDataTypes.TICK_DELTA, tickDelta);
        state.setStateData(StateDataTypes.CONTROLLERS, entity.getAnimationControllers());
        state.setStateData(StateDataTypes.MODEL_PROVIDER, getModelProvider());
        state.setStateData(StateDataTypes.ANIMATION_TIME, state.ageInTicks / 20f);
    }

    /// Setups rotation for living entities
    public <SL extends LivingEntityRenderState> void setupRotations(SL state, PoseStack poseStack, float bodyYaw, float scale) {
        livingEntityStateGetter.rotate(state, poseStack, bodyYaw, scale);
    }

    /// @return max model rotation when entity is dead or dying, applied only to living entities
    public float getFlipDegrees() {
        return 90f;
    }

    @ApiStatus.Internal
    private record LivingRenderStateGetter<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>>(LivingEntityRenderer<T, S, M> renderer) {
        private LivingRenderStateGetter(EntityRendererProvider.Context context, float deathFlipDegrees) {
            this(new LivingEntityRenderer<>(context, null, 0) {
                @Override
                public Identifier getTextureLocation(LivingEntityRenderState livingEntityRenderState) {
                    return null;
                }

                @Override
                public S createRenderState() {
                    return null;
                }

                @Override
                protected float getFlipDegrees() {
                    return deathFlipDegrees;
                }
            });
        }

        public void fillRenderState(T entity, S state, float tickDelta) {
            renderer.extractRenderState(entity, state, tickDelta);
        }

        public float getWhiteOverlayProgress(S state) {
            return renderer.getWhiteOverlayProgress(state);
        }

        public void rotate(S livingEntityRenderState, PoseStack poseStack, float bodyYaw, float scale) {
            renderer.setupRotations(livingEntityRenderState, poseStack, bodyYaw, scale);
        }
    }

    @ApiStatus.Internal
    private record MobRenderStateGetter<T extends Mob, S extends LivingEntityRenderState, M extends EntityModel<? super S>>(MobRenderer<T, S, M> renderer) {
        private MobRenderStateGetter(EntityRendererProvider.Context context) {
            this(new MobRenderer<>(context, null, 0) {
                @Override
                public Identifier getTextureLocation(LivingEntityRenderState livingEntityRenderState) {
                    return null;
                }

                @Override
                public S createRenderState() {
                    return null;
                }
            });
        }

        public void fillRenderState(T entity, S state, float tickDelta) {
            renderer.extractRenderState(entity, state, tickDelta);
        }
    }
}
