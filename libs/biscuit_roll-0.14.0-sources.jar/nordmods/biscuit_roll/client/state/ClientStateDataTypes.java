package nordmods.biscuit_roll.client.state;

import libs.gg.moonflower.pinwheel.api.geometry.bone.AnimatedBone;
import it.unimi.dsi.fastutil.booleans.BooleanBooleanPair;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import nordmods.biscuit_roll.BiscuitRoll;
import nordmods.biscuit_roll.common.state.StateDataType;
import org.jetbrains.annotations.ApiStatus;

import java.util.Map;

/// Build in [StateDataType] that can be called from client side only.
/// Attempting to call this class from server side will cause [ClassNotFoundException] on dedicated servers
public class ClientStateDataTypes {
    public static final StateDataType<ModelFeatureRenderer.CrumblingOverlay> CRUMBLING_OVERLAY = new StateDataType<>(BiscuitRoll.id("crumbling_overlay"));
    public static final StateDataType<Integer> OVERLAY_TEXTURE = new StateDataType<>(BiscuitRoll.id("overlay_texture"));
    public static final StateDataType<Integer> OUTLINE_COLOR = new StateDataType<>(BiscuitRoll.id("outline_color"));
    public static final StateDataType<Integer> COLOR = new StateDataType<>(BiscuitRoll.id("color"));
    public static final StateDataType<Integer> LIGHT = new StateDataType<>(BiscuitRoll.id("light"));
    public static final StateDataType<Boolean> INVISIBLE = new StateDataType<>(BiscuitRoll.id("invisible"));
    @ApiStatus.Internal
    public static final StateDataType<Map<AnimatedBone, BooleanBooleanPair>> BONE_VISIBILITY_OVERRIDES = new StateDataType<>(BiscuitRoll.id("bone_visibility_overrides"));
}
