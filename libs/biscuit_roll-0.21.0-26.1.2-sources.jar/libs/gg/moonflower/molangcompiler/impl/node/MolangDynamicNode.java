package libs.gg.moonflower.molangcompiler.impl.node;

import libs.gg.moonflower.molangcompiler.api.MolangEnvironment;
import libs.gg.moonflower.molangcompiler.api.MolangExpression;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Supplier;

/**
 * @author Ocelot
 */
@ApiStatus.Internal
public record MolangDynamicNode(Supplier<Float> value) implements MolangExpression {
    
    @Override
    public float get(MolangEnvironment environment) {
        return this.value.get();
    }

    @Override
    public String toString() {
        return Float.toString(this.value.get());
    }
}
