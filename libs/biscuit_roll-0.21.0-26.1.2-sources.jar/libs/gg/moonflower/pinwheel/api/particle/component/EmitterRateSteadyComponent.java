package libs.gg.moonflower.pinwheel.api.particle.component;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import libs.gg.moonflower.molangcompiler.api.MolangExpression;
import libs.gg.moonflower.pinwheel.api.JsonTupleParser;

/**
 * Component that summons particles at a steady rate until too many particles are spawned.
 *
 * @author Ocelot
 * @since 1.0.0
 */
public record EmitterRateSteadyComponent(MolangExpression spawnRate,
                                         MolangExpression maxParticles) implements ParticleEmitterComponent {

    public static final MolangExpression DEFAULT_SPAWN_RATE = MolangExpression.of(1);
    public static final MolangExpression DEFAULT_MAX_PARTICLES = MolangExpression.of(50);

    public static EmitterRateSteadyComponent deserialize(JsonElement json) throws JsonParseException {
        JsonObject object = json.getAsJsonObject();
        return new EmitterRateSteadyComponent(
                JsonTupleParser.getExpression(object, "spawn_rate", () -> EmitterRateSteadyComponent.DEFAULT_SPAWN_RATE),
                JsonTupleParser.getExpression(object, "max_particles", () -> EmitterRateSteadyComponent.DEFAULT_MAX_PARTICLES));
    }
}
