package libs.gg.moonflower.molangcompiler.impl.node;

import libs.gg.moonflower.molangcompiler.api.MolangEnvironment;
import libs.gg.moonflower.molangcompiler.api.MolangExpression;
import libs.gg.moonflower.molangcompiler.api.bridge.MolangVariable;
import org.jetbrains.annotations.ApiStatus;

/**
 * @author Ocelot
 */
@ApiStatus.Internal
public record MolangVariableNode(MolangVariable value) implements MolangExpression, MolangVariable {

    @Override
    public float get(MolangEnvironment environment) {
        return this.value.getValue();
    }

    @Override
    public String toString() {
        return Float.toString(this.value.getValue());
    }

    @Override
    public float getValue() {
        return this.value.getValue();
    }

    @Override
    public void setValue(float value) {
        this.value.setValue(value);
    }

    @Override
    public MolangExpression createCopy() {
        return new MolangVariableNode(this.copy());
    }

    @Override
    public MolangVariable copy() {
        return this.value.copy();
    }
}
