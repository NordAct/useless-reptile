package nordmods.biscuit_roll.client.util;

import com.mojang.blaze3d.vertex.PoseStack;
import libs.gg.moonflower.pinwheel.api.geometry.bone.Vertex;
import nordmods.biscuit_roll.common.model.BRModel;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector3fc;

import java.util.function.Consumer;

public class RenderUtil {
    /// Helps with item rendering
    /// @param model item model
    /// @param poseStack extents stack
    /// @param consumer where result will be written to
    public static void getExtentsForGui(BRModel model, PoseStack poseStack, Consumer<Vector3fc> consumer) {
        model.render((_, polygon) -> {
            Matrix4f matrix4f = poseStack.last().pose();
            Vector3f vector3f = new Vector3f();

            for (Vertex vertex : polygon.vertices()) {
                float vertexX = vertex.x();
                float vertexY = vertex.y();
                float vertexZ = vertex.z();

                matrix4f.transformPosition(vertexX, vertexY, vertexZ, vector3f);
                consumer.accept(vector3f);
            }
        }, poseStack);
    }
}
