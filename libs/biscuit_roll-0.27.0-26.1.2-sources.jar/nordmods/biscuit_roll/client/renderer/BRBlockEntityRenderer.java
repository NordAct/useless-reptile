package nordmods.biscuit_roll.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import libs.gg.moonflower.molangcompiler.api.MolangEnvironment;
import libs.gg.moonflower.molangcompiler.api.MolangEnvironmentBuilder;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import nordmods.biscuit_roll.client.renderer.layer.BRRenderLayer;
import nordmods.biscuit_roll.client.state.ClientStateDataTypes;
import nordmods.biscuit_roll.client.util.TextureAtlasSpriteUtil;
import nordmods.biscuit_roll.common.animation.BRAnimatedObject;
import nordmods.biscuit_roll.common.model.BRModelProvider;
import nordmods.biscuit_roll.common.model.BRModel;
import nordmods.biscuit_roll.common.state.StateDataTypes;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/// Implementation of {@link BRRenderer} for {@link BlockEntity}
/// @see BRObjectRenderer
/// @see BREntityRenderer
public abstract class BRBlockEntityRenderer<T extends BlockEntity & BRAnimatedObject, S extends BlockEntityRenderState> implements BlockEntityRenderer<@NonNull T, S>, BRRenderer<S> {
    private final BRModelProvider modelProvider;
    private final List<BRRenderLayer> renderLayers = new ArrayList<>();

    protected BRBlockEntityRenderer(BRModelProvider modelProvider) {
        this.modelProvider = modelProvider;
    }

    @Override
    public void beforeSubmit(S state, PoseStack poseStack, SubmitNodeCollector submitNodeCollector, @Nullable CameraRenderState cameraRenderState) {
        poseStack.translate(0.5, 0, 0.5);
        poseStack.scale(-1, -1, 1);
    }

    @Override
    public void submit(@NonNull S state, @NonNull PoseStack poseStack, @NonNull SubmitNodeCollector submitNodeCollector, @Nullable CameraRenderState cameraRenderState) {
        submitBRModel(state, poseStack, submitNodeCollector, cameraRenderState);
    }

    @Override
    public BRModelProvider getModelProvider() {
        return modelProvider;
    }

    @Override
    public Collection<BRRenderLayer> getRenderLayers() {
        return renderLayers;
    }

    @Override
    public void extractRenderState(@NonNull T blockEntity, @NonNull S state, float tickDelta, @NonNull Vec3 cameraPos, ModelFeatureRenderer.CrumblingOverlay crumblingOverlay) {
        blockEntity.getAnimationControllers().forEach(controller -> updateControllerVariables(controller.getEnvironment().edit(), blockEntity, tickDelta));
        BlockEntityRenderer.super.extractRenderState(blockEntity, state, tickDelta, cameraPos, crumblingOverlay);
        state.setStateData(StateDataTypes.CONTROLLERS, blockEntity.getAnimationControllers());
        state.setStateData(StateDataTypes.MODEL_PROVIDER, getModelProvider());
        state.setStateData(StateDataTypes.ANIMATION_TIME, getAnimationTime(blockEntity, state, tickDelta));
        state.setStateData(ClientStateDataTypes.CRUMBLING_OVERLAY, crumblingOverlay);
        state.setStateData(ClientStateDataTypes.LIGHT, state.lightCoords);
    }

    /// Updates variables and queries for each controller during {@link BRModel#applyAnimations(MolangEnvironment, Collection)}.
    /// Note: `query.anim_time` gets updated during {@link BRModel#applyAnimations(MolangEnvironment, Collection) regardless
    /// @param builder provided by controller Molang environment
    /// @param blockEntity block entity from which data for queries and values is gotten
    /// @param tickDelta current tick progress
    /// @see QueryHelper
    public void updateControllerVariables(MolangEnvironmentBuilder<?> builder, T blockEntity, float tickDelta) {}

    /// @param blockEntity block entity
    /// @return BE's current tick time
    public abstract int getCurrentTick(T blockEntity);

    /// @return block entity reference animation time in seconds
    public float getAnimationTime(T blockEntity, S state, float tickDelta) {
        return  (getCurrentTick(blockEntity) + tickDelta) / 20f;
    }

    @Override
    public @Nullable TextureAtlasSprite getSpriteForTexture(Identifier texture) {
        return TextureAtlasSpriteUtil.getTextureAtlasSprite(Sheets.BLOCKS_MAPPER, texture);
    }

    @Override
    public String debugName() {
        return "Block Entity";
    }
}
